package ron.admin.service;

import java.util.ArrayList;
import java.util.List;

import ron.admin.model.Ron_Order;



public interface OrderService {
	public void save(Ron_Order order);
	public void update(Ron_Order order);
	public void delete(Integer o_id);
	public Ron_Order srchById(Integer o_id);
	public ArrayList<Ron_Order> orderBy(int currentPage, int lines,
			 String columnName, String s2b,int srchType,String orderSearch);
	public ArrayList<Ron_Order> OrderByCol(int currentPage, int lines,
			 String columnName, String s2b,int srchType,String orderSearch);
	public int getPage(int lines,int srchType, String orderSearch);
	public int getCount(int srchType, String orderSearch);
//	public int totalPage(int line);
//	public List findByPage(int page, int line);
//	public void deleteIds(String [] ids);
}
