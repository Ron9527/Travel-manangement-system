package ron.admin.service;

import ron.admin.model.Adm_info;

public interface AdminService {
	//查询用户
	public Adm_info srchAdm(int num);
	//添加新用户
	public void insertAdm(Adm_info newAdm);
	//判断账号密码是否正确
	public boolean checkAdm(int num,String pwd);
	//退出账号
	public void logOff();
}
