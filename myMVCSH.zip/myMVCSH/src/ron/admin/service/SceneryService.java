package ron.admin.service;

import java.util.ArrayList;

import ron.admin.model.SceneryDetail;

public interface SceneryService {
	public ArrayList<SceneryDetail> srchAllScenery();
}
