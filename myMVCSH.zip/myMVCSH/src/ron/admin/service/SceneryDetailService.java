package ron.admin.service;

import java.util.ArrayList;
import java.util.List;

import ron.admin.model.Ron_Order;
import ron.admin.model.SceneryDetail;

public interface SceneryDetailService {
//	public ArrayList<SceneryDetail> srchSceneryByType(String type);
	
	public void save(SceneryDetail sd);
	public void update(SceneryDetail sd);
	public void delete(Integer sd_id);
	public SceneryDetail srchById(Integer sd_id);
	public ArrayList<SceneryDetail> sceneryOrderBy(int currentPage, int lines,
			 String columnName, String s2b,int srchType,String orderSearch);
	public ArrayList<SceneryDetail> sceneryOrderByCol(int currentPage, int lines,
			 String columnName, String s2b,int srchType,String orderSearch);
	public int getPage(int lines,int srchType, String orderSearch);
	public int getCount(int srchType, String orderSearch);
}
