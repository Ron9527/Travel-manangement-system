package ron.admin.dao;

import ron.admin.model.Adm_info;

public interface AdminDao {
	//根据账号查询
	public Adm_info srchAdm(int num);
	//注册新用户
	public void insertAdm(Adm_info newAdm);
	//退出账号
	public void logOff();
}
