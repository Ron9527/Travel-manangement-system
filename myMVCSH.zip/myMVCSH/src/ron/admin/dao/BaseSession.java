package ron.admin.dao;

import org.hibernate.Session;

public interface BaseSession {
	public Session getSession();
	public int getOrderNumbers(int srchType, String orderSearch);
	public int getOrderPageNum(int lines,int srchType, String orderSearch);
	public int getSceneryNumbers(int srchType);
	public int getSceneryPageNum(int lines,int srchType);
}
