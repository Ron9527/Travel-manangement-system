package ron.admin.dao;

import java.util.ArrayList;

import ron.admin.model.SceneryDetail;

public interface SceneryDetailDao {
//	public ArrayList<SceneryDetail> srchSceneryByType(String type);
	public void insertScenery(SceneryDetail sd);
	public void updateScenery(SceneryDetail sd);
	public void delete(SceneryDetail sd);
	public SceneryDetail srchById(Integer sd_id);
	public ArrayList<SceneryDetail> sceneryOrderBy(int currentPage, int lines,
			String columnName, String s2b, int srchType, String orderSearch);
	public ArrayList<SceneryDetail> sceneryOrderByCol(int currentPage,
			int lines, String columnName, String s2b, int srchType,
			String orderSearch);
//	public int getSceneryPageNum(int lines, int srchType);
//	public int getSceneryNumbers(int srchType);
	
}
