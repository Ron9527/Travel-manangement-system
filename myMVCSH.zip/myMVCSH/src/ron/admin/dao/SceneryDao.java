package ron.admin.dao;

import java.util.ArrayList;

import ron.admin.model.SceneryDetail;

public interface SceneryDao {
	public ArrayList<SceneryDetail> srchAllScenery();
}
