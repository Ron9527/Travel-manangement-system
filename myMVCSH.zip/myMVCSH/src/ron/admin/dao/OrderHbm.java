package ron.admin.dao;

import java.util.ArrayList;

import ron.admin.model.Ron_Order;

public interface OrderHbm {
	public Ron_Order srchByNum(String className, String columnName, int num);
	public void updateOrder(Ron_Order updateOrder);
	public ArrayList<Ron_Order> orderBy(int currentPage, int lines,
			 String orderType, String desc,int srchType,String orderSearch);
	public ArrayList<Ron_Order> orderByCol(int currentPage, int
			 lines, String columnName, String s2b,int srchType,String orderSearch);
}
