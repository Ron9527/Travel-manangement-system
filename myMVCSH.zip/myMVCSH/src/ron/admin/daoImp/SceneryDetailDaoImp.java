package ron.admin.daoImp;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import org.hibernate.Query;
import org.hibernate.SQLQuery;

import ron.admin.dao.SceneryDetailDao;
import ron.admin.model.Ron_Order;
import ron.admin.model.Scenery;
import ron.admin.model.SceneryDetail;

public class SceneryDetailDaoImp extends BaseSessionImp implements SceneryDetailDao{
	private ArrayList<SceneryDetail> sds;
	private SceneryDetail sd;
	private String hql;
	
	
//	public ArrayList<SceneryDetail> srchSceneryByType(String type){
//		try {
//			type = new String(type.getBytes("iso8859-1"),"utf-8");
//		} catch (UnsupportedEncodingException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		SQLQuery query = getSession().createSQLQuery("select sd_id ,sd_name ,sd_price ,sd_runtime,sd_mark, sd_tickets ,sd_loc ,sd_image ,sd_info ,sd_traveltime  from myscenery,myscenerydetail where sd_id=ss_id and ss_type like '%"+type+"%'").addEntity(SceneryDetail.class);
////		query.addEntity(.class);
//		sds = (ArrayList<SceneryDetail>) query.list();
//		for(int i=0;i<sds.size();i++){
//			System.out.println("------"+sds.get(i).getSd_id());
//		}
//		return sds;
//	}
	
	@Override
	public void insertScenery(SceneryDetail sd) {
		// TODO Auto-generated method stub
		getSession().save(sd);
		
	}
	@Override
	public void updateScenery(SceneryDetail sd) {
		// TODO Auto-generated method stub
		getSession().merge(sd);
		
	}
	@Override
	public void delete(SceneryDetail sd) {
		// TODO Auto-generated method stub
		getSession().delete(sd);
		
	}
	@Override
	public SceneryDetail srchById(Integer sd_id) {
		// TODO Auto-generated method stub
		sd = (SceneryDetail) getSession().get(SceneryDetail.class, sd_id);
		System.out.println("sd_id"+sd.getSd_id());
		return sd;
	}
	@Override
	public ArrayList<SceneryDetail> sceneryOrderBy(int currentPage, int lines,
			String columnName, String s2b, int srchType, String orderSearch) {
		// TODO Auto-generated method stub
		System.out.println("srchType=" + srchType);
		String content = "";
//		if (!orderSearch.equals(null)) {
//		if(orderSearch==null){
			switch(srchType)
			{
			case 1:
				content = ",myscenery where sd_id=ss_id and ss_type like '%自然风光%'";
				break;
			case 2:
				content = ",myscenery where sd_id=ss_id and ss_type like '%名胜古迹%'";
				break;
			case 3:
				content = ",myscenery where sd_id=ss_id and ss_type like '%观光街区%'";
				break;
			case 4:
				content = ",myscenery where sd_id=ss_id and ss_type like '%公园游乐场%'";
				break;
			case 5:
				content = ",myscenery where sd_id=ss_id and ss_type like '%演出演艺%'";
				break;
			case 6:
				content = ",myscenery where sd_id=ss_id and ss_type like '%其它景点%'";
				break;
			default:
				break;
			}
			
//		}
//		}
//		if ("desc".equals(s2b)) {
//			hql = "select sd_id ,sd_name ,sd_price ,sd_runTime,sd_mark, sd_tickets ,sd_loc ,sd_image ,sd_info ,sd_travelTime  from myscenerydetail"+content;
//		} else {
			hql = "select sd_id ,sd_name ,sd_price ,sd_runTime,sd_mark, sd_tickets ,sd_loc ,sd_image ,sd_info ,sd_travelTime  from myscenerydetail"+content;
//		}
//		Query query = getSession().createQuery("from SceneryDetail");
		

		SQLQuery query = getSession().createSQLQuery(hql).addEntity(SceneryDetail.class);
		query.setFirstResult((currentPage - 1) * lines);
		query.setMaxResults(lines);
		sds = (ArrayList<SceneryDetail>) query.list();
		return sds;
	}
	@Override
	public ArrayList<SceneryDetail> sceneryOrderByCol(int currentPage,
			int lines, String columnName, String s2b, int srchType,
			String orderSearch) {
		// TODO Auto-generated method stub
		System.out.println("srchType======" + srchType);
		String content = "";
//		if(orderSearch==null){
//			switch(srchType)
//			{
//			case 1:
//				content = " and ss_type like '%自然风光%'";
//				break;
//			case 2:
//				content = " and ss_type like '%名胜古迹%'";
//				break;
//			case 3:
//				content = " and ss_type like '%观光街区%'";
//				break;
//			case 4:
//				content = " and ss_type like '%公园游乐场%'";
//				break;
//			default:
//				break;
//			}
//		}

		hql = "select sd_id ,sd_name ,sd_price ,sd_runTime,sd_mark, sd_tickets ,sd_loc ,sd_image ,sd_info ,sd_travelTime  from myscenery,myscenerydetail where sd_id=ss_id and ss_type like '%自然风光%'"+content;

		SQLQuery query = getSession().createSQLQuery(hql).addEntity(SceneryDetail.class);
		query.setFirstResult((currentPage - 1) * lines);
		query.setMaxResults(lines);
		sds = (ArrayList<SceneryDetail>) query.list();
		return sds;
	}

}
