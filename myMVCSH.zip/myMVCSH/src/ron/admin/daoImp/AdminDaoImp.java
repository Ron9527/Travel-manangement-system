package ron.admin.daoImp;

import org.hibernate.Query;

import ron.admin.dao.AdminDao;
import ron.admin.model.Adm_info;

public class AdminDaoImp extends BaseSessionImp implements AdminDao{
	private Adm_info adm;

	public Adm_info srchAdm(int num){
		String hql = "from Adm_info where adm_num = "+num;
		Query query = getSession().createQuery(hql);
		if(query.list().size()>0){
			adm =  (Adm_info) query.list().get(0);
		}
		else{
			adm=null;
		}
		return adm;
	}

	public void insertAdm(Adm_info newAdm){
		getSession().save(newAdm);
		adm = (Adm_info)getSession().load(Adm_info.class, newAdm.getAdm_num());
		if(adm != null){
			System.out.println("zhucechenggong");
		}
		else{
			System.out.println("failed");
		}
	}

	public void logOff(){
		getSession().clear();
	}
}
