package ron.admin.daoImp;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Transaction;

import ron.admin.dao.OrderHbm;
import ron.admin.model.Ron_Order;

public class OrderHbmImp extends BaseSessionImp implements OrderHbm {
	// 事件对象
	Transaction tx = null;
	// 相关数据总数
	int count;
	// 数据分页后总页数
	int totalPage;
	// 当前页码
	int currentPage;
	// hql语句
	String hql;
	// 管理员对象
	// Adm_info adm;
	// 管理员对象组
	// ArrayList<Adm_info> adms;
	// 订单对象
	Ron_Order ronOrder;
	// 订单对象组
	ArrayList<Ron_Order> ronOrders;

	// 查询所有用户
	// public ArrayList<Adm_info> searchAll() {
	// try {
	// tx = getSession().beginTransaction();
	// // String countHQL = ""
	// String hql = "from Adm_info";
	// Query query = session.createQuery(hql);
	// adms = (ArrayList<Adm_info>) query.list();
	// } catch (HibernateException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// tx.rollback();
	// } finally {
	// if (null != session) {
	// closeSession();
	// }
	// }
	// return adms;
	// }
	// 查询用户
	// public Adm_info srchAdm(int num){
	// try {
	// tx = getSession().beginTransaction();
	// // String countHQL = ""
	// String hql = "from Adm_info where adm_num = "+num;
	// Query query = session.createQuery(hql);
	// if(query.list().size()>0){
	// adm = (Adm_info) query.list().get(0);
	// }
	// else{
	// adm=null;
	// }
	// } catch (HibernateException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// tx.rollback();
	// } finally {
	// if (null != session) {
	// closeSession();
	// }
	// }
	// return adm;
	// }
	public Ron_Order srchByNum(String className, String columnName, int num) {
		try {
			tx = getSession().beginTransaction();
			// String countHQL = ""
			String hql = "from " + className + " where " + columnName + " = "
					+ num;
			Query query = getSession().createQuery(hql);
			if (query.list().size() > 0) {
				ronOrder = (Ron_Order) query.list().get(0);
			} else {
				ronOrder = null;
			}
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			tx.rollback();
		} finally {
			if (null != getSession()) {
				getSession().close();
			}
		}
		return ronOrder;
	}

	public Ron_Order srchByNum(int o_id) {
		ronOrder = (Ron_Order) getSession().get(Ron_Order.class, o_id);
		return ronOrder;
	}

	public void updateOrder(Ron_Order updateOrder) {
		getSession().merge(updateOrder);
		// System.out.println("merge```````");
	}

	// public Ron_Order updateOrder(Ron_Order updateOrder) {
	// try {
	// tx = getSession().beginTransaction();
	// // String countHQL = ""
	// session.update(updateOrder);
	// ronOrder = (Ron_Order) session.load(Ron_Order.class,
	// updateOrder.getO_id());
	// if (ronOrder != null) {
	// System.out.println("update success");
	// } else {
	// System.out.println("update failed");
	// }
	// tx.commit();
	// } catch (HibernateException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// tx.rollback();
	// } finally {
	// if (null != session) {
	// closeSession();
	// }
	// }
	// return ronOrder;
	// }

	// 添加新订单
	public void insertOrder(Ron_Order order) {
		getSession().save(order);
	}

	// 删除订单
	public void deleteOrder(Ron_Order order) {
		getSession().delete(order);
	}

	// 注册新用户
	// public void insertAdm(Adm_info newUser){
	// try {
	// tx = getSession().beginTransaction();
	// // String countHQL = ""
	// session.save(newUser);
	// adm = (Adm_info)session.load(Adm_info.class, newUser.getAdm_num());
	// if(adm != null){
	// System.out.println("zhucechenggong");
	// }
	// else{
	// System.out.println("failed");
	// }
	// tx.commit();
	// // String hql = "from Adm_info where adm_num = "+num;
	// // Query query = session.createQuery(hql);
	// // adm = (Adm_info) query.list().get(0);
	// } catch (HibernateException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// tx.rollback();
	// } finally {
	// if (null != session) {
	// closeSession();
	// }
	// }
	// }

	// currentPage当前页，lines每页行数，columnName排序类型，s2b升降序,srchType按条件查询,orderSearch查询内容
	public ArrayList<Ron_Order> orderByCol(int currentPage, int lines,
			String columnName, String s2b, int srchType, String orderSearch) {
		System.out.println("srchType=" + srchType);
		String content = "";

		try {
			orderSearch = new String(orderSearch.getBytes(),"UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("orderSearch=" + orderSearch);
		if (!orderSearch.equals(null)) {
			switch (srchType) {
			case 1:

				content = " where o_uname like '%" + orderSearch + "%'";

				break;
			case 2:

				content = " where o_sname like '%" + orderSearch + "%'";

				break;
			case 3:

				content = " where o_state like '%" + orderSearch + "%'";

				break;
			case 4:
				content = " where o_duedate like '%" + orderSearch + "%'";

				break;
			default:
				content = "";
				break;
			}
		}
		hql = "from Ron_Order" + content + " order by " + columnName + " "
				+ s2b;
		Query query = getSession().createQuery(hql);
		query.setFirstResult((currentPage - 1) * lines);
		query.setMaxResults(lines);
		ronOrders = (ArrayList<Ron_Order>) query.list();
		return ronOrders;
	}

	// orderBy依据XX排序，currentPage当前页，lines每页行数，orderType排序类型，desc升降序,srchType按条件查询,orderSearch查询内容
	public ArrayList<Ron_Order> orderBy(int currentPage, int lines,
			String columnName, String s2b, int srchType, String orderSearch) {
		System.out.println("srchType=" + srchType);
		String content = "";
//		String orderSearch1="";
//		try {
//			orderSearch1 = new String(orderSearch.getBytes(),"UTF-8");
//		} catch (UnsupportedEncodingException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		System.out.println("orderSearch~~~~=" + orderSearch1);
		if (!orderSearch.equals(null)) {
			switch (srchType) {
			case 1:
				content = " where o_uname like '%" + orderSearch + "%'";
				break;
			case 2:
				content = " where o_sname like '%" + orderSearch + "%'";
				break;
			case 3:
				content = " where o_state like '%" + orderSearch + "%'";

				break;
			case 4:
				content = " where o_duedate like '%" + orderSearch + "%'";
				break;
			default:
				content = "";
				break;
			}
		}
		if ("desc".equals(s2b)) {
			hql = "from Ron_Order" + content + " order by " + columnName + " "
					+ s2b;
		} else {
			hql = "from Ron_Order" + content + " order by " + columnName;
		}
		Query query = getSession().createQuery(hql);
		query.setFirstResult((currentPage - 1) * lines);
		query.setMaxResults(lines);

		ronOrders = (ArrayList<Ron_Order>) query.list();
		return ronOrders;
	}

	// public void insertAdm(Adm_info adm) {
	// try {
	// // conf = new Configuration().configure();
	// // sessionFactory = conf.buildSessionFactory();
	// // session = sessionFactory.openSession();
	// // tx = session.beginTransaction();
	// tx = getSession().beginTransaction();
	// session.save(adm);
	// // 按照主键自动修改
	// // session.update(adm);
	// // 按照对象删除
	// // session.delete(adm);
	// // 查询get(类名.class,primary key)
	// // Adm_info adm = (Adm_info)session.get(Adm_info.class,1);
	// // Adm_info adm = (Adm_info)session.load(Adm_info.class,1);
	// // 查询特殊要求的数据
	// // from 类名
	// // String hql="from Adm_info";
	// // Query query = session.createQuery(hql);
	// // List<Adm_info> list = query.list();
	// System.out.println("hbm chenggong");
	// tx.commit();
	// } catch (HibernateException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// tx.rollback();
	// } finally {
	// if (null != session) {
	// session.close();
	// }
	// }
	// }
}
