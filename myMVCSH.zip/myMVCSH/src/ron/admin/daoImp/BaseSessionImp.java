package ron.admin.daoImp;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import ron.admin.dao.BaseSession;
import ron.admin.model.SceneryDetail;

public class BaseSessionImp implements BaseSession{
	Configuration conf = null;
	SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public Session getSession() {

		return sessionFactory.getCurrentSession();
	}


	public int getOrderNumbers(int srchType, String orderSearch) {
		String countHQL = "select count(*) from Ron_Order";
		Query query = this.getSession().createQuery(countHQL);
		List list = query.list();
		int count = Integer.parseInt(list.get(0).toString());
		return count;
	}
	public int getSceneryNumbers(int srchType) {
		String content = "";
		switch (srchType) {
		case 1:
			content = "where sd_id in (select ss_id from myscenery where ss_type like '%自然风光%')";
			break;
		case 2:
			content = "where sd_id in (select ss_id from myscenery where ss_type like '%名胜古迹%')";
			break;
		case 3:
			content = "where sd_id in (select ss_id from myscenery where ss_type like '%观光街区%')";

			break;
		case 4:
			content = "where sd_id in (select ss_id from myscenery where ss_type like '%公园游乐场%')";
			break;
		case 5:
			content = "where sd_id in (select ss_id from myscenery where ss_type like '%演出演艺%')";
			break;
		case 6:
			content = "where sd_id in (select ss_id from myscenery where ss_type like '%其它景点%')";
			break;
		default:
			content = "";
			break;
		}
		String countHQL = "select count(*) from myscenerydetail "+content;


		SQLQuery query = getSession().createSQLQuery(countHQL);
		// query.setParameter(0, className);
		List list = query.list();
		int count = Integer.parseInt(list.get(0).toString());
		return count;
	}
	public int getOrderPageNum(int lines,int srchType, String orderSearch) {
		int totalPage = (this.getOrderNumbers(srchType,orderSearch) % lines == 0) ? (this
				.getOrderNumbers(srchType,orderSearch) / lines) : (this.getOrderNumbers(srchType,orderSearch)
				/ lines + 1);
		return totalPage;
	}
	public int getSceneryPageNum(int lines,int srchType) {
		int totalPage = (this.getSceneryNumbers(srchType) % lines == 0) ? (this
				.getSceneryNumbers(srchType) / lines) : (this.getSceneryNumbers(srchType)
				/ lines + 1);
		return totalPage;
	}
}
