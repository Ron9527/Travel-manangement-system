package ron.admin.daoImp;

import java.util.ArrayList;

import org.hibernate.Query;

import ron.admin.dao.SceneryDao;
import ron.admin.model.SceneryDetail;

public class SceneryDaoImp extends BaseSessionImp implements SceneryDao{
	private ArrayList<SceneryDetail> sds;
	public ArrayList<SceneryDetail> srchAllScenery(){
/*		try {
			type = new String(type.getBytes("iso8859-1"),"utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		SQLQuery query = getSession().createSQLQuery("select sd_id ,sd_name ,sd_price ,sd_runtime,sd_mark, sd_tickets ,sd_loc ,sd_image ,sd_info ,sd_traveltime  from myscenery,myscenerydetail where sd_id=ss_id and ss_type like '%"+type+"%'");
//		query.addEntity(.class);
		scenerys = (ArrayList<Scenery>) query.list();*/
		Query query = getSession().createQuery("from SceneryDetail");
		sds = (ArrayList<SceneryDetail>) query.list();
		return sds;
	}
}
