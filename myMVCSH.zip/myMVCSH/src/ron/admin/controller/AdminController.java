package ron.admin.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import ron.admin.model.Adm_info;
import ron.admin.service.AdminService;

@Controller
@RequestMapping("admin")
public class AdminController {
	@Autowired
	private AdminService adminService;
	@Autowired
	private HttpServletRequest request;
	
//注册新用户
	@RequestMapping("/insertAdm.do")
	public String insertAdm(Adm_info newAdm){
		adminService.insertAdm(newAdm);
		request.getSession().setAttribute("adm", newAdm);
		return "admin/registerResult";
	}
//查询账号密码
	@RequestMapping("/logIn.do")
	public String logIn(int num,String pwd){
		if(adminService.checkAdm(num, pwd)){
			request.getSession().setAttribute("adm", adminService.srchAdm(num));
			return "admin/homePage";
		}
		else{
			return "admin/loginFailed";
		}
	}
//退出账号
	@RequestMapping("/logOff.do")
	public String logOff(){
//		adminService.logOff();
		request.getSession().removeAttribute("adm");
		return "admin/homePage";
	}
}
