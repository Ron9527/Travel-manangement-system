package ron.admin.controller;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import ron.admin.model.Ron_Order;
import ron.admin.service.OrderService;


@Controller
@RequestMapping("order")
public class OrderController {
	@Autowired
	private OrderService orderService;
	@Autowired
	private HttpServletRequest request;
	protected int totalPage;
	private ArrayList<Ron_Order> ronOrders;
	private Ron_Order order;
	private int count;
	@RequestMapping("/insertOrder.do")
	public String insertOrder(Ron_Order order,Integer currentPage,Integer lines, String columnName,String s2b,int srchType,String orderSearch){
		orderService.save(order);
		return orderBy(currentPage,lines,columnName,s2b,srchType,orderSearch);
	}
	@RequestMapping("/updateOrder.do")
	public String updateOrder(Ron_Order order,Integer currentPage,Integer lines, String columnName,String s2b,int srchType,String orderSearch){
		System.out.println("sid==="+order.getO_sid());
		orderService.update(order);
		return orderBy(currentPage,lines,columnName,s2b,srchType,orderSearch);
	}
	@RequestMapping("/orderBy.do")
	public String orderBy(Integer currentPage,Integer lines, String columnName,String s2b,int srchType,String orderSearch){
		try {
			String str = new String(orderSearch.getBytes("iso8859-1"),"utf-8");
			System.out.println(str+"*************");
			ronOrders = orderService.orderBy(currentPage, lines, columnName, s2b,srchType,str);
			totalPage = orderService.getPage(lines,srchType,str);
			count = orderService.getCount(srchType,str);
			System.out.println("totalpage==="+totalPage);
			request.setAttribute("ronOrders", ronOrders);
			request.setAttribute("currentPage", currentPage);
			request.setAttribute("lines", lines);
			request.setAttribute("s2b", s2b);
			request.setAttribute("columnName", columnName);
			request.setAttribute("totalPage", totalPage);
			request.setAttribute("count", count);
			request.setAttribute("srchType", srchType);		
			request.setAttribute("orderSearch", str);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "order/order";
	}
	@RequestMapping("/searchOrder.do")
	public String searchOrder(Integer o_id, int lines){
		order = orderService.srchById(o_id);
		request.setAttribute("ronOrder", order);
		return "order/modify";
	}
	@RequestMapping("/deleteOrder.do")
	public String deleteOrder(int o_id,Integer currentPage,Integer lines, String columnName,String s2b,int srchType,String orderSearch){
		orderService.delete(o_id);
		return orderBy(currentPage,lines,columnName,s2b,srchType,orderSearch);
	}
	@RequestMapping("/OrderByCol.do")
	public String OrderByCol(Integer currentPage,Integer lines, String columnName,String s2b,int srchType,String orderSearch){
		try {
			System.out.println("srchType==="+srchType);
			
			String str = new String(orderSearch.getBytes("iso8859-1"),"utf-8");
			System.out.println("orderSearch==="+str);
			ronOrders = orderService.orderBy(currentPage, lines, columnName, s2b,srchType,str);
			totalPage = orderService.getPage(lines,srchType,str);
			count = orderService.getCount(srchType,str);
			request.setAttribute("ronOrders", ronOrders);
			request.setAttribute("currentPage", currentPage);
			request.setAttribute("lines", lines);
			request.setAttribute("s2b", s2b);
			request.setAttribute("columnName", columnName);
			request.setAttribute("totalPage", totalPage);
			request.setAttribute("count", count);
			request.setAttribute("srchType", srchType);
			request.setAttribute("orderSearch", str);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "order/order";
	}
}
