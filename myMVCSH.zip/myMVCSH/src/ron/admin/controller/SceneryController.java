package ron.admin.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import ron.admin.model.SceneryDetail;
import ron.admin.service.SceneryService;

@Controller
@RequestMapping("scenery")
public class SceneryController {
	@Autowired
	private SceneryService sService;
	@Autowired
	private HttpServletRequest request;
	private ArrayList<SceneryDetail> scenerys;
	@RequestMapping("/srchAllScenery.do")
	public String srchAllScenery(){
		scenerys = sService.srchAllScenery();
		request.setAttribute("sds", scenerys);
		System.out.println("sd.sd_id"+scenerys.get(0).getSd_id());
		return "scenery/sceneryDetails";
	}
}
