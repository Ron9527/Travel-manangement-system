package ron.admin.controller;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import ron.admin.model.Ron_Order;
import ron.admin.model.SceneryDetail;
import ron.admin.service.SceneryDetailService;

@Controller
@RequestMapping("sceneryDetail")
public class SceneryDetailController {
	@Autowired
	private SceneryDetailService sdService;
	@Autowired
	private HttpServletRequest request;
	private ArrayList<SceneryDetail> sds;
	private SceneryDetail sd;
	protected int totalPage;
	private int count;
//	@RequestMapping("/srchSceneryByType.do")
//	public String srchSceneryByType(String type){
//		System.out.println("~~~~~~~~~~~~~~~");
//		sds = sdService.srchSceneryByType(type);
//		request.setAttribute("sds", sds);
//		System.out.println("sds.size"+sds.size());
////		System.out.println("sd.sd_id"+sds.get(0).getSd_id());
//		return "scenery/sceneryDetails";
//	}
	@RequestMapping("/insertSceneryDetail.do")
	public String insertSceneryDetail(SceneryDetail sd,Integer currentPage,Integer lines, String columnName,String s2b,int srchType,String orderSearch){
		sdService.save(sd);
		return sceneryOrderBy(currentPage,lines,columnName,s2b,srchType,orderSearch);
	}
	@RequestMapping("/updateSceneryDetail.do")
	public String updateSceneryDetail(SceneryDetail sd,Integer currentPage,Integer lines, String columnName,String s2b,int srchType,String orderSearch){
//		System.out.println("sid==="+order.getO_sid());
		sdService.update(sd);
		return sceneryOrderBy(currentPage,lines,columnName,s2b,srchType,orderSearch);
	}
	@RequestMapping("/sceneryOrderBy.do")
	public String sceneryOrderBy(Integer currentPage,Integer lines, String columnName,String s2b,int srchType,String orderSearch){
		try {
			String str = new String(orderSearch.getBytes("iso8859-1"),"utf-8");
			System.out.println(str+"*************");
			sds = sdService.sceneryOrderBy(currentPage, lines, columnName, s2b,srchType,str);
			totalPage = sdService.getPage(lines,srchType,str);
			count = sdService.getCount(srchType,str);
//			System.out.println("totalpage==="+totalPage);
			request.setAttribute("sds", sds);
			request.setAttribute("currentPage", currentPage);
			request.setAttribute("lines", lines);
			request.setAttribute("s2b", s2b);
			request.setAttribute("columnName", columnName);
			request.setAttribute("totalPage", totalPage);
			request.setAttribute("count", count);
			request.setAttribute("srchType", srchType);		
			request.setAttribute("orderSearch", str);
			System.out.println("scenery count   "+count);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "scenery/sceneryDetails";
	}
	@RequestMapping("/sceneryOrderByCol.do")
	public String sceneryOrderByCol(Integer currentPage,Integer lines, String columnName,String s2b,int srchType,String orderSearch){
		try {
			System.out.println("srchType==="+srchType);
			
			String str = new String(orderSearch.getBytes("iso8859-1"),"utf-8");
			System.out.println("orderSearch==="+str);
			sds = sdService.sceneryOrderBy(currentPage, lines, columnName, s2b,srchType,str);
			totalPage = sdService.getPage(lines,srchType,str);
			count = sdService.getCount(srchType,str);
			request.setAttribute("sds", sds);
			request.setAttribute("currentPage", currentPage);
			request.setAttribute("lines", lines);
			request.setAttribute("s2b", s2b);
			request.setAttribute("columnName", columnName);
//			request.setAttribute("totalPage", totalPage);
//			request.setAttribute("count", count);
			request.setAttribute("srchType", srchType);
			request.setAttribute("orderSearch", str);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "order/order";
	}
	@RequestMapping("/searchScenery.do")
	public String searchScenery(Integer sd_id, int lines){
		System.out.println("==========searchScenery");
		sd = sdService.srchById(sd_id);
		request.setAttribute("sd", sd);
		return "scenery/modify";
	}
	@RequestMapping("/deleteScenery.do")
	public String deleteScenery(int sd_id,Integer currentPage,Integer lines, String columnName,String s2b,int srchType,String orderSearch){
		sdService.delete(sd_id);
		return sceneryOrderBy(currentPage,lines,columnName,s2b,srchType,orderSearch);
	}
}
