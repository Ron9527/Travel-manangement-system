package ron.admin.serviceImp;

import java.util.ArrayList;
import java.util.List;

import ron.admin.daoImp.OrderHbmImp;
import ron.admin.model.Ron_Order;
import ron.admin.service.OrderService;

public class OrderServiceImp implements OrderService{
	private OrderHbmImp orderHbm;
	private Ron_Order order;
	private ArrayList<Ron_Order> orders;
	@Override
	public void save(Ron_Order order) {
		// TODO Auto-generated method stub
		orderHbm.insertOrder(order);
	}

	@Override
	public void update(Ron_Order order) {
		// TODO Auto-generated method stub
		orderHbm.updateOrder(order);
	}

	@Override
	public void delete(Integer o_id) {
		// TODO Auto-generated method stub
		order = orderHbm.srchByNum(o_id);
		if(order!=null){
			orderHbm.deleteOrder(order);
		}
		else{
			System.out.println("未查到此订单");
		}
	}

	@Override
	public Ron_Order srchById(Integer o_id) {
		// TODO Auto-generated method stub
		return orderHbm.srchByNum(o_id);
	}



	@Override
	public ArrayList<Ron_Order> orderBy(int currentPage, int lines,
			 String columnName, String s2b,int srchType,String orderSearch) {
		// TODO Auto-generated method stub
		System.out.println("lines=="+lines);
		orders = orderHbm.orderBy(currentPage, lines, columnName, s2b, srchType, orderSearch);
		if(orders !=null){
			return orders;
		}
		else{
			System.out.println("订单排序错误");
			return null;
		}

	}
	@Override
	public ArrayList<Ron_Order> OrderByCol(int currentPage, int lines,
			String columnName, String s2b,int srchType,String orderSearch) {
		// TODO Auto-generated method stub
		orders=orderHbm.orderByCol(currentPage, lines, columnName, s2b, srchType, orderSearch);
		if(orders !=null){
			return orders;
		}
		else{
			System.out.println("订单排序错误");
			return null;
		}
	}

	@Override
	public int getCount(int srchType, String orderSearch) {
		// TODO Auto-generated method stub
		return orderHbm.getOrderNumbers(srchType,orderSearch);
	}
	@Override
	public int getPage(int lines,int srchType, String orderSearch) {
		// TODO Auto-generated method stub
		return orderHbm.getOrderPageNum(lines,srchType,orderSearch);
	}
	public OrderHbmImp getOrderHbm() {
		return orderHbm;
	}

	public void setOrderHbm(OrderHbmImp orderHbm) {
		this.orderHbm = orderHbm;
	}






}
