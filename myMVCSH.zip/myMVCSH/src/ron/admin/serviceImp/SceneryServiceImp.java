package ron.admin.serviceImp;

import java.util.ArrayList;

import ron.admin.dao.SceneryDao;
import ron.admin.model.Scenery;
import ron.admin.model.SceneryDetail;
import ron.admin.service.SceneryService;

public class SceneryServiceImp implements SceneryService{
	private Scenery scenery;
	private ArrayList<SceneryDetail> scenerys;
	private SceneryDao sDao;
	public ArrayList<SceneryDetail> srchAllScenery(){
		scenerys=sDao.srchAllScenery();
		return scenerys;
	}
	public SceneryDao getsDao() {
		return sDao;
	}
	public void setsDao(SceneryDao sDao) {
		this.sDao = sDao;
	}

}
