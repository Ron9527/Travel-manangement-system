package ron.admin.serviceImp;

import ron.admin.daoImp.AdminDaoImp;
import ron.admin.model.Adm_info;
import ron.admin.service.AdminService;

public class AdminServiceImp implements AdminService{
	private AdminDaoImp admDao;

	public Adm_info srchAdm(int num){
		return admDao.srchAdm(num);
	}

	public void insertAdm(Adm_info newAdm){
		admDao.insertAdm(newAdm);
	}

	public boolean checkAdm(int num,String pwd){
		if(admDao.srchAdm(num)!=null&&pwd.equals(admDao.srchAdm(num).getAdm_pwd())){
			return true;
		}
		return false;
	}
	public void logOff(){
		admDao.logOff();
	}

	public AdminDaoImp getAdmDao() {
		return admDao;
	}

	public void setAdmDao(AdminDaoImp admDao) {
		this.admDao = admDao;
	}
	
}
