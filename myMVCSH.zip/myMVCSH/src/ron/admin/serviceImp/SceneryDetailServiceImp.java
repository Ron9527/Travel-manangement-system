package ron.admin.serviceImp;

import java.util.ArrayList;

import ron.admin.dao.SceneryDetailDao;
import ron.admin.daoImp.SceneryDetailDaoImp;
import ron.admin.model.SceneryDetail;
import ron.admin.service.SceneryDetailService;

public class SceneryDetailServiceImp implements SceneryDetailService{
	private SceneryDetail sd;
	private ArrayList<SceneryDetail> sds;
	private SceneryDetailDaoImp sdDao;
//	public ArrayList<SceneryDetail> srchSceneryByType(String type){
//		sds=sdDao.srchSceneryByType(type);
//		return sds;
//	}

	@Override
	public void save(SceneryDetail sd) {
		// TODO Auto-generated method stub
		sdDao.insertScenery(sd);
	}
	@Override
	public void update(SceneryDetail sd) {
		// TODO Auto-generated method stub
		sdDao.updateScenery(sd);
		
	}
	@Override
	public void delete(Integer sd_id) {
		// TODO Auto-generated method stub
		sd = sdDao.srchById(sd_id);
		if(sd!=null){
			sdDao.delete(sd);
		}
		else{
			System.out.println("未查到此订单");
		}

		
	}
	@Override
	public SceneryDetail srchById(Integer sd_id) {
		// TODO Auto-generated method stub
		return sdDao.srchById(sd_id);
	}
	@Override
	public ArrayList<SceneryDetail> sceneryOrderBy(int currentPage, int lines,
			String columnName, String s2b, int srchType, String orderSearch) {
		// TODO Auto-generated method stub
		sds = sdDao.sceneryOrderBy(currentPage, lines, columnName, s2b, srchType, orderSearch);
		if(sds !=null){
			return sds;
		}
		else{
			System.out.println("订单排序错误");
			return null;
		}
	}
	@Override
	public ArrayList<SceneryDetail> sceneryOrderByCol(int currentPage,
			int lines, String columnName, String s2b, int srchType,
			String orderSearch) {
		// TODO Auto-generated method stub
		sds=sdDao.sceneryOrderByCol(currentPage, lines, columnName, s2b, srchType, orderSearch);
		if(sds !=null){
			return sds;
		}
		else{
			System.out.println("订单排序错误");
			return null;
		}
	}
	@Override
	public int getPage(int lines, int srchType, String orderSearch) {
		// TODO Auto-generated method stub
		return sdDao.getSceneryPageNum(lines,srchType);
	}
	@Override
	public int getCount(int srchType, String orderSearch) {
		// TODO Auto-generated method stub
		return sdDao.getSceneryNumbers(srchType);
	}
	public SceneryDetailDaoImp getSdDao() {
		return sdDao;
	}
	public void setSdDao(SceneryDetailDaoImp sdDao) {
		this.sdDao = sdDao;
	}

}
