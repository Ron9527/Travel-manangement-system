package ron.admin.model;


//管理员编号（pk）    登录密码             姓名                        性别               所属部门 (num)   
//adm_num       adm_pwd	   adm_name	    adm_sex	 adm_deptno	   
//入职时间               顾问等级(num)      联络手机(num,un)      邮箱地址(un) 
//adm_date	  adm_lv	       adm_phone	       adm_email
public class Adm_info {
		public Adm_info(int adm_num, String adm_pwd, String adm_name,
			String adm_sex, int adm_deptno, String adm_date, int adm_lv,
			String adm_phone, String adm_email, String adm_state) {
		super();
		this.adm_num = adm_num;
		this.adm_pwd = adm_pwd;
		this.adm_name = adm_name;
		this.adm_sex = adm_sex;
		this.adm_deptno = adm_deptno;
		this.adm_date = adm_date;
		this.adm_lv = adm_lv;
		this.adm_phone = adm_phone;
		this.adm_email = adm_email;
		this.adm_state = adm_state;
	}
		private int adm_num;
		private String adm_pwd;
		private String adm_name;
		private String adm_sex;
		private int adm_deptno;
		private String adm_date;
		private int adm_lv;
		private String adm_phone;
		private String adm_email;
		private String adm_state;
		
		public String getAdm_state() {
			return adm_state;
		}
		public void setAdm_state(String adm_state) {
			this.adm_state = adm_state;
		}
		public int getAdm_num() {
			return adm_num;
		}
		public void setAdm_num(int adm_num) {
			this.adm_num = adm_num;
		}
		public int getAdm_deptno() {
			return adm_deptno;
		}
		public void setAdm_deptno(int adm_deptno) {
			this.adm_deptno = adm_deptno;
		}
		public int getAdm_lv() {
			return adm_lv;
		}
		public void setAdm_lv(int adm_lv) {
			this.adm_lv = adm_lv;
		}
		public String getAdm_phone() {
			return adm_phone;
		}
		public void setAdm_phone(String adm_phone) {
			this.adm_phone = adm_phone;
		}
		public String getAdm_pwd() {
			return adm_pwd;
		}
		public void setAdm_pwd(String adm_pwd) {
			this.adm_pwd = adm_pwd;
		}
		public String getAdm_name() {
			return adm_name;
		}
		public void setAdm_name(String adm_name) {
			this.adm_name = adm_name;
		}
		public String getAdm_sex() {
			return adm_sex;
		}
		public void setAdm_sex(String adm_sex) {
			this.adm_sex = adm_sex;
		}
		public String getAdm_date() {
			return adm_date;
		}
		public void setAdm_date(String adm_date) {
			this.adm_date = adm_date;
		}
		public String getAdm_email() {
			return adm_email;
		}
		public void setAdm_email(String adm_email) {
			this.adm_email = adm_email;
		}
		public Adm_info() {
			super();
			// TODO Auto-generated constructor stub
		}
		public Adm_info(int adm_num, String adm_pwd, String adm_name,
				String adm_sex, int adm_deptno, String adm_date, int adm_lv,
				String adm_phone, String adm_email) {
			super();
			this.adm_num = adm_num;
			this.adm_pwd = adm_pwd;
			this.adm_name = adm_name;
			this.adm_sex = adm_sex;
			this.adm_deptno = adm_deptno;
			this.adm_date = adm_date;
			this.adm_lv = adm_lv;
			this.adm_phone = adm_phone;
			this.adm_email = adm_email;
		}
		public Adm_info(String adm_pwd) {
			super();
			this.adm_pwd = adm_pwd;
		}

		
	
}
