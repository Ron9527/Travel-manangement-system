package ron.admin.model;

public class Ron_Order {
	//订单编号
	private int o_id;
	//景点编号
	private int o_sid;
//	景点名称
	private String o_sname;
//	用户编号
	private int o_uid;
//	用户名称
	private String o_uname;
//	订单状态
	private String o_state;
//	订单有效期
	private String o_duedate;
	public int getO_id() {
		return o_id;
	}
	public void setO_id(int o_id) {
		this.o_id = o_id;
	}
	public int getO_sid() {
		return o_sid;
	}
	public void setO_sid(int o_sid) {
		this.o_sid = o_sid;
	}
	public String getO_sname() {
		return o_sname;
	}
	public void setO_sname(String o_sname) {
		this.o_sname = o_sname;
	}
	public int getO_uid() {
		return o_uid;
	}
	public void setO_uid(int o_uid) {
		this.o_uid = o_uid;
	}
	public String getO_uname() {
		return o_uname;
	}
	public void setO_uname(String o_uname) {
		this.o_uname = o_uname;
	}
	public String getO_state() {
		return o_state;
	}
	public void setO_state(String o_state) {
		this.o_state = o_state;
	}
	public String getO_duedate() {
		return o_duedate;
	}
	public void setO_duedate(String o_duedate) {
		this.o_duedate = o_duedate;
	}
	public Ron_Order(int o_id, int o_sid, String o_sname, int o_uid,
			String o_uname, String o_state, String o_duedate) {
		this.o_id = o_id;
		this.o_sid = o_sid;
		this.o_sname = o_sname;
		this.o_uid = o_uid;
		this.o_uname = o_uname;
		this.o_state = o_state;
		this.o_duedate = o_duedate;
	}
	public Ron_Order() {
		// TODO Auto-generated constructor stub
	}
	
}
