package ron.admin.model;

public class Scenery {
	// 景点编号
	private int ss_id;
	// 景点名称
	private String ss_name;
	// 景点类型
	private String ss_type;

	public int getSs_id() {
		return ss_id;
	}

	public void setSs_id(int ss_id) {
		this.ss_id = ss_id;
	}

	public String getSs_name() {
		return ss_name;
	}

	public void setSs_name(String ss_name) {
		this.ss_name = ss_name;
	}

	public String getSs_type() {
		return ss_type;
	}

	public void setSs_type(String ss_type) {
		this.ss_type = ss_type;
	}

	public Scenery(int ss_id, String ss_name, String ss_type) {
		this.ss_id = ss_id;
		this.ss_name = ss_name;
		this.ss_type = ss_type;
	}

	public Scenery() {

	}

}
