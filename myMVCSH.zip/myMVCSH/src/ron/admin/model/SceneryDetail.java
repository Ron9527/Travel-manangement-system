package ron.admin.model;

public class SceneryDetail {
    private int sd_id;
	private String sd_name;
	private int sd_price;
	private String sd_runTime;
	private double sd_mark;
	private int sd_tickets;
	private String sd_loc;
	private String sd_image;
	private String sd_info;
	private String sd_travelTime;
	public int getSd_id() {
		return sd_id;
	}
	public void setSd_id(int sd_id) {
		this.sd_id = sd_id;
	}
	public String getSd_name() {
		return sd_name;
	}
	public void setSd_name(String sd_name) {
		this.sd_name = sd_name;
	}
	public int getSd_price() {
		return sd_price;
	}
	public void setSd_price(int sd_price) {
		this.sd_price = sd_price;
	}
	public String getSd_runTime() {
		return sd_runTime;
	}
	public void setSd_runTime(String sd_runTime) {
		this.sd_runTime = sd_runTime;
	}
	public double getSd_mark() {
		return sd_mark;
	}
	public void setSd_mark(double sd_mark) {
		this.sd_mark = sd_mark;
	}
	public int getSd_tickets() {
		return sd_tickets;
	}
	public void setSd_tickets(int sd_tickets) {
		this.sd_tickets = sd_tickets;
	}
	public String getSd_loc() {
		return sd_loc;
	}
	public void setSd_loc(String sd_loc) {
		this.sd_loc = sd_loc;
	}
	public String getsd_image() {
		return sd_image;
	}
	public void setsd_image(String sd_image) {
		this.sd_image = sd_image;
	}
	public String getSd_info() {
		return sd_info;
	}
	public void setSd_info(String sd_info) {
		this.sd_info = sd_info;
	}
	public String getSd_travelTime() {
		return sd_travelTime;
	}
	public void setSd_travelTime(String sd_travelTime) {
		this.sd_travelTime = sd_travelTime;
	}
	public SceneryDetail(int sd_id, String sd_name, int sd_price,
			String sd_runTime, double sd_mark, int sd_tickets, String sd_loc,
			String sd_image, String sd_info, String sd_travelTime) {
		this.sd_id = sd_id;
		this.sd_name = sd_name;
		this.sd_price = sd_price;
		this.sd_runTime = sd_runTime;
		this.sd_mark = sd_mark;
		this.sd_tickets = sd_tickets;
		this.sd_loc = sd_loc;
		this.sd_image = sd_image;
		this.sd_info = sd_info;
		this.sd_travelTime = sd_travelTime;
	}
	public SceneryDetail() {
	}
	
	
}
